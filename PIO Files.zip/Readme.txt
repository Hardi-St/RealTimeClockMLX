Compile with PlatformIO by calling from the command line
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The files must be copied to:
..\Documents\Arduino\MobaLedLib\Ver_3.5.0


Changes to the Prog_Generator MobaLedLib (3.5.0C1):
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
M38_Extentions line 433
  Public Function Write_PIO_Extension(fp As Integer) As Boolean
    Dim Extension, Index As Integer

    For Index = 0 To ExtensionsActive.Count - 1
       Print #fp, "    " & ExtensionsActive.Items(Index).Name & "=file://" & GetShortPath(ExtensionsActive.Items(Index).path)   '19.12.25: Hardi
      'Print #fp, "    " & ExtensionsActive(Index).Name & "=file://" & GetShortPath(ExtensionsActive(Index).path)
    Next
    Write_PIO_Extension = True

  End Function

Load the configuration:
  Word_Clock_akt_WLAN.MLL_pgf
in the Prog_Generator and set the correct Filter (Only one "Txt ...")
and generate the LEDs_AutoProg.h

To install PlatformIO the following files are needed:
  install_platformio.cmd
  _INTERNAL_platformio_install.ps1
