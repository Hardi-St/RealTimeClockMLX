@echo off
REM Revision History:
REM ~~~~~~~~~~~~~~~~~
REM 11.11.23:  Added new PIP path "%USERPROFILE%\.platformio\penv\Scripts\"


SET Baud=%1
REM The early ESP boot messages uses 115200 => They are shown as hyroglyphs if 460800 baud is used ;-(
if "%1" =="" SET Baud=115200
REM if "%1" =="" SET Baud=460800

REM To log the results to a file use Powershel (Ver 7.2) and enter
REM   Serial_Monitor.cmd | TEE -Encoding ascii Messages.txt
REM
REM To show timestamps enter
REM  ctrl+t ctrl+f time



REM Filter options (See https://bit.ly/pio-monitor-filters)
REM Filters:
REM Achtung: Die Reihenfolge ist wichtig!!
REM  --filter esp32_exception_decoder  Geht nur wenn im Projektverzeichnis gestartet wird und wenn "--filter time" nachher aufgerufen wird
REM  --filter time                     Enable the timestamp
REM  --filter printable                Es kommen leider immer noch Zeichen die MultiEdit nicht mag und darum auf HEX umschaltet
REM  --filter log2file                 Log the outputs to a file

REM Start the serial monitor
pio device monitor -b %Baud% --echo --filter esp32_exception_decoder
