@echo off
REM Revision History:
REM ~~~~~~~~~~~~~~~~~
REM 11.11.23:  Added new PIP path "%USERPROFILE%\.platformio\penv\Scripts\"

REM Bei der Installation von Phyton muss man unten "Add path..." anklicken.
REM Danach das script "get-platformio.py" herunterladen und mit
REM  python get-platformio.py
REM starten.

REM Tools:
REM ~~~~~~
REM Gesammten Flash l�schen: esptool --port com6 erase_flash
REM
REM Backup erzeugen:         esptool --chip esp32 --port com6 --baud 921600 read_flash  0 All esp32_devkit_dump.bin
REM Backup schreiben:        esptool --chip esp32 --port com6 --baud 921600 write_flash 0 esp32_devkit_dump.bin
REM
REM Use parameter "-t nobuild" to upload without new build


Set Env=esp32

REM Use parameter "-t nobuild" to upload without new build

pio run -e %Env%  -t upload %1 %2 %3 %4 %5 %6 %7 %8 %9
IF errorlevel 1 Goto :eof

REM Filter options (See https://bit.ly/pio-monitor-filters)
REM Filters:
REM Achtung: Die Reihenfolge ist wichtig!!
REM  --filter esp32_exception_decoder  Geht nur wenn im Projektverzeichnis gestartet wird und wenn "--filter time" nachher aufgerufen wird
REM  --filter time                     Enable the timestamp
REM  --filter printable                Es kommen leider immer noch Zeichen die MultiEdit nicht mag und darum auf HEX umschaltet
REM  --filter log2file                 Log the outputs to a file

REM Start the serial monitor (The ESP32 seames to have problems with 1000000 baud)
REM Old 500000 (The Excel serial Monitor seames to have problems with 500000)   115200
REM The early ESP boot messages use 115200 => They are shown as hyroglyphs if 460800 baud is used ;-(
REM pio device monitor -b 460800 --echo --filter esp32_exception_decoder --filter time --filter log2file
     pio device monitor -b 115200 --echo --filter time
REM  pio device monitor -b 115200 --echo --filter esp32_exception_decoder --filter time
