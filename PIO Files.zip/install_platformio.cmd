@echo off
echo Starte PlatformIO Installer...
echo.

powershell -NoProfile -ExecutionPolicy Bypass ^
  -File "%~dp0_INTERNAL_platformio_install.ps1"

echo.
pause

